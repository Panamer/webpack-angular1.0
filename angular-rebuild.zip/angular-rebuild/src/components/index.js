import Home from './home';
import Login from './login';
import InterfaceBoard from './interfaceBoard';

export default angular.module('components', [
    Login,
    Home,
    InterfaceBoard
]).name;
